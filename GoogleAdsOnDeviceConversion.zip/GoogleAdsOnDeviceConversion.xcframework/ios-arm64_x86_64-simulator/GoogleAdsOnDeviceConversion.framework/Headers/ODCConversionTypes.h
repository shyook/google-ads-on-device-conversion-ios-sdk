#import <Foundation/Foundation.h>

/// The type of interaction for fetching conversion info.
typedef NS_ENUM(NSInteger, ODCInteractionType) {
  ODCInteractionTypeInstallation,
} NS_SWIFT_NAME(InteractionType);
